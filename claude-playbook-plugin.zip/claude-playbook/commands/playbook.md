---
description: Scaffold, start, check, tail, or stop a Claude Code playbook run
---
The user ran `/playbook` with arguments: $ARGUMENTS

Use the `claude-playbook` MCP tools to act on the request. Map the first word of the
arguments to a tool (default the playbook path to `./playbook.yaml` when none is given):

- `new` or `scaffold` [path]  -> `scaffold_playbook`  (blank starter)
- `handoff` [path]            -> `handoff_session`   (capture THIS session to continue later)
- `start` [path]              -> `start_playbook`
- `status` [path]             -> `playbook_status`
- `logs` [path] [n]           -> `playbook_logs`
- `stop` [path]               -> `stop_playbook`

If no arguments are given: call `playbook_status` for `./playbook.yaml`; if that playbook
does not exist, offer to scaffold one. Keep the reply concise — report phase, progress
(done/total), cost, and the most relevant log lines. Never block waiting on a run; it
executes detached and continues through usage-limit resets on its own.
